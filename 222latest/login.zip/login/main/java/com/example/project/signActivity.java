package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;

public class signActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    EditText name;
    EditText surname;
    EditText mailAddress;
    EditText password;
    Button sign;
    private FirebaseUser user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);
        mAuth = FirebaseAuth.getInstance();
        name=findViewById(R.id.name);
        surname=findViewById(R.id.surname);
        mailAddress=findViewById(R.id.mailAddress);
        password=findViewById(R.id.password);
        user = mAuth.getCurrentUser();

    }


    private boolean isGtuMail(String email) {
        return email.endsWith("@gtu.edu.tr");
    }

    public void setSign(View view) {
        String userName = name.getText().toString();
        String userSurname = surname.getText().toString()   ;
        String userMail = mailAddress.getText().toString();
        String userPass = password.getText().toString();

       /*
        Eğer teacher kaydetmek istiyorsam ve bu teacher listesinde varsa kullanıcı yaratırım. Yoksa
        student olarak kaydederim.
        ArrayList<String> teachers = new ArrayList<String>();

        if(teachers.contains(userMail)){

        }
       */

        if (!isGtuMail(userMail)) {
            Toast.makeText(this, "Please enter your gtu mail", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this,signActivity.class);
            startActivity(intent);

        }else{
            mAuth.createUserWithEmailAndPassword(userMail,userPass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                @Override
                public void onSuccess(AuthResult authResult) {
                    user.sendEmailVerification();
                   // registerVerification();
                    Toast.makeText(signActivity.this,"You sign up Succesfully",Toast.LENGTH_LONG).show();
                }


            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(signActivity.this,e.getLocalizedMessage().toString(),Toast.LENGTH_LONG).show();
                }

            });
            Intent intent = new Intent(this,loginActivity.class);
            startActivity(intent);
        }


    }
}
